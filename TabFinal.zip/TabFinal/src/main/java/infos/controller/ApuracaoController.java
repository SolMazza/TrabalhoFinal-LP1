package infos.controller;

import infos.repository.*;
import infos.exception.*;
import infos.model.*;
import javax.persistence.PersistenceException;
import java.util.Calendar;
import java.util.List;

public class ApuracaoController {

    private FuncionarioRepository funcionarioRepository;
    private RestauranteRepository restauranteRepository;
    private VotoRepository votoRepository;

    public ApuracaoController() {
        this.funcionarioRepository = new FuncionarioRepository();
        this.restauranteRepository = new RestauranteRepository();
        this.votoRepository = new VotoRepository();
    }

    public void votar(String funcionarioNome, String restauranteNome) throws ExecuteException {
        Funcionario funcionario = adicionarFuncionario(funcionarioNome);
        Restaurante restaurante = adicionarRestaurante(restauranteNome);
        Calendar data = Calendar.getInstance();

        if (votoRepository.busca(funcionario, data).isEmpty()) {
            Voto voto = new Voto(data, funcionario, restaurante);
            System.out.println("voto criado, teste");
            funcionario.votar(voto);
            System.out.println("voto adicionado, teste");
            funcionarioRepository.atualizar(funcionario);
            System.out.println("voto atualixar, teste");
        } else {
            throw new ExecuteException("Funcionário já votou hoje.");
        }
    }

    public void votar(String funcionarioNome, int restauranteid) throws ExecuteException {
        Funcionario funcionario = adicionarFuncionario(funcionarioNome);
        Restaurante restaurante = restauranteRepository.buscarID(restauranteid);
        Calendar data = Calendar.getInstance();

        if (votoRepository.busca(funcionario, data).isEmpty()) {
            Voto voto = new Voto(data, funcionario, restaurante);
            funcionario.votar(voto);
            funcionarioRepository.atualizar(funcionario);
        } else {
            throw new ExecuteException("Funcionário já votou hoje.");
        }
    }

    public Funcionario adicionarFuncionario(String nome) throws ExecuteException {
        Funcionario funcionario = funcionarioRepository.buscarPorNome(nome);
        if (funcionario == null) {
            funcionario = new Funcionario(nome);
            try {
                funcionarioRepository.inserir(funcionario);
            } catch (PersistenceException e) {
                throw new ExecuteException("Falha ao inserir funcionario");
            }
        }
        return funcionario;
    }

    public Restaurante adicionarRestaurante(String nome) throws ExecuteException {
        Restaurante restaurante = restauranteRepository.buscarPorNome(nome);
        if (restaurante == null) {
            restaurante = new Restaurante(nome);
            try {
                restauranteRepository.inserir(restaurante);
            } catch (PersistenceException e) {
                throw new ExecuteException("Falha ao inserir restaurante");
            }
        }
        return restaurante;
    }


    public List<Funcionario> listarFuncionario() throws ExecuteException {
        List<Funcionario> funcionarios = funcionarioRepository.buscar();

        if (funcionarios.isEmpty()) {
            throw new ExecuteException("Não há funcionários registrados");
        }
        return funcionarios;
    }

    public List<Restaurante> listarRestaurante() throws ExecuteException {
        List<Restaurante> restaurantes = restauranteRepository.buscar();
        if (restaurantes.isEmpty()) {
            throw new ExecuteException("Não há restaurantes registrados");
        }
        return restaurantes;
    }


    public void apurarVotacao() {
        Calendar data = Calendar.getInstance();
        List<Voto> votos = votoRepository.apuracao(data);

        if (votos.isEmpty()){
            System.out.println("ainda nao ha votos hoje");
        }
        for(Voto voto : votos) {
            System.out.println("|" + voto.getFuncionario().getNome() + "|");
            System.out.println("|" + voto.getRestaurante().getNome() + "|");
        }
    }
}

